import { Line } from 'react-chartjs-2';
import 'chart.js/auto';

function Dashboard({ role }) {
  const data = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr'],
    datasets: [{
      label: 'Expenses',
      data: [1200, 1900, 800, 1600],
      borderColor: 'rgb(75, 192, 192)',
      fill: false,
    }],
  };

  return (
    <div className="p-6 min-h-screen bg-gradient-to-br from-white to-blue-50">
      <h1 className="text-3xl font-extrabold mb-6 text-blue-800">Dashboard ({role})</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <StatBox label="Total Expenses" value="$5,500" color="blue" />
        <StatBox label="Pending Approvals" value="8" color="orange" />
        <StatBox label="Reports Generated" value="3" color="green" />
      </div>
      <div className="bg-white rounded-2xl shadow-xl p-6">
        <h2 className="text-xl font-bold mb-4 text-gray-700">Monthly Expense Trend</h2>
        <Line data={data} />
      </div>
    </div>
  );
}

function StatBox({ label, value, color }) 
{
  return (
    <div className="bg-white p-4 rounded-xl shadow-lg text-center">
      <h2 className="text-lg font-semibold text-gray-600">{label}</h2>
      <p className={\`text-2xl font-bold text-\${color}-600\`}>{value}</p>
    </div>
  );
  
  
  
  
  
  
}

export default Dashboard;