function ExpensePage() {
  return (
    <div className="p-6 min-h-screen bg-gradient-to-br from-white to-blue-50">
      <h1 className="text-3xl font-extrabold mb-6 text-blue-800">Expenses</h1>
      <div className="bg-white rounded-xl p-4 shadow-md">
        <p className="text-gray-700">List of expenses, with create/update/delete options.</p>
      </div>
    </div>
  );
}

export default ExpensePage;