function ApprovalsPage() {
  return (
    <div className="p-6 min-h-screen bg-gradient-to-br from-white to-purple-100">
      <h1 className="text-3xl font-extrabold mb-6 text-purple-800">Approvals</h1>
      <div className="bg-white rounded-xl p-4 shadow-md">
        <p className="text-gray-700">Approval workflow for managers and admins.</p>
      </div>
    </div>
  );
}

export default ApprovalsPage;