import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

function LoginPage({ onLogin }) {
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-blue-100 to-purple-200">
      <Card className="w-96 p-6 shadow-2xl border-2 border-white backdrop-blur-md">
        <CardContent>
          <h2 className="text-2xl font-bold mb-4 text-center text-gray-800">Welcome to EEMS</h2>
          <Button className="w-full mb-2" onClick={() => onLogin('employee')}>Login as Employee</Button>
          <Button className="w-full mb-2" onClick={() => onLogin('manager')}>Login as Manager</Button>
          <Button className="w-full" onClick={() => onLogin('admin')}>Login as Admin</Button>
        </CardContent>
      </Card>
    </div>
  );
}

export default LoginPage;